## Installation with Cocoapods

* Add to your Podfile
  ```
  use_frameworks!
  pod 'DynamicMobileVLCKit', :http => 'https://bauloc.github.io/FPTPLAY/MobileVLCKit/v3.3.13/DynamicMobileVLCKit.zip'
  