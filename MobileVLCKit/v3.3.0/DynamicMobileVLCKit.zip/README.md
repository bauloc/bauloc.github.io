## Installation with Cocoapods

* Add to your Podfile
  ```
  use_frameworks!
  pod 'DynamicMobileVLCKit', :http => 'https://bauloc.github.io/MobileVLCKit/v3.3.0/DynamicMobileVLCKit.zip'
  